/**
 * @file noise_meter.c
 *
 * @mainpage Noise Meter
 *
 * @section description Description
 * This program turns the Raspberry Pi Pico W (RP2040) into a noise meter.
 * The code includes support to measure sound levels using an ADC (Analog-to-Digital Converter) connected to a microphone.
 * It also allows the user to save the average sound level with a timestamp to an EEPROM (Electrically Erasable Programmable Read-Only Memory) using I2C communication.
 * The system starts in an idle state where it waits for the user to press a button to start measuring the sound level.
 * While in operation, the system measures the sound level for a duration of 10 seconds and calculates the average sound level in decibels (dB).
 * After the measurement, it saves the average sound level along with the timestamp to the EEPROM.
 * The user can also press another button to dump the stored sound level data from the EEPROM and display it.
 * Additionally, there is a reset button to erase all the stored data from the EEPROM.
 * The LEDs provide feedback on the system state: green for idle, yellow for operation, blue for successful completion, and red for cancellation.
 *
 * @section circuit Circuit
 * - Push-button connected to GP15 for starting measurement
 * - Push-button connected to GP16 for dumping data from EEPROM
 * - Push-button connected to GP20 for resetting EEPROM memory
 * - LEDs connected to GP13 (green), GP12 (yellow), GP11 (blue), and GP10 (red) for feedback
 * - Analog microphone connected to ADC pin GP26
 *
 * @section libraries Libraries
 * - math.h
 *   - Used for mathematical calculations, such as logarithms and square roots.
 * - stdio.h
 *   - Standard Input/Output library for printing debug information.
 * - pico/stdlib.h
 *   - Standard library associated with the Pico Board.
 * - hardware/gpio.h
 *   - Library for manipulating General Purpose Input/Output (GPIO) pins.
 * - hardware/adc.h
 *   - Library for Analog-to-Digital Converter (ADC) operations.
 * - hardware/i2c.h
 *   - Library for Inter-Integrated Circuit (I2C) communication.
 * - pico/util/datetime.h
 *   - Library for handling date and time.
 * - time.h
 *   - Standard library for time-related functions.
 * - string.h
 *   - Standard library for string manipulation.
 *
 * @section notes Notes
 * - This project implements a polling methodology for button presses and an interrupt-based approach for button debouncing.
 * - Default values and configurations can be adjusted for specific use cases and testing purposes.
 *
 * @section todo ToDo
 * - Further optimization of code structure and functionalities.
 * - Implement additional features such as real-time monitoring and data analysis.
 *
 * @section author Authors
 * - Created by Santiago Giraldo Tabares & Ana María Velasco Montenegro on april, 2024
 *
 *
 * Copyright (c) No-license.
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/i2c.h"
#include "hardware/rtc.h"
#include <math.h>
#include "pico/util/datetime.h"
#include <string.h>
#include <time.h>
#include "microphone.h"

// GPIO pins
#define ADC_NUM 0
#define ADC_PIN (26 + ADC_NUM)
#define ADC_VREF 3.3
#define ADC_RANGE (1 << 12)
#define ADC_CONVERT (ADC_VREF / (ADC_RANGE - 1))
#define SAMPLES 100

#define PUSH_BUTTON_PIN 15
#define DUMP_BUTTON_PIN 16
#define GREEN_LED_PIN 13
#define YELLOW_LED_PIN 12
#define BLUE_LED_PIN 11
#define RED_LED_PIN 10
#define RESET_BUTTON_PIN 20 // GPIO 20 for reset button

// I2C pins
#define I2C_SDA_PIN 4
#define I2C_SCL_PIN 5
#define I2C_PORT i2c0
#define EEPROM_ADDRESS 0x50

#define IDLE 0
#define OPERATION 1
#define SUCCESSFUL 2
#define CANCELLED 3


int main() {
    stdio_init_all();
    printf("System initializing...\n");

    uint64_t start_time = 0; // Declare start_time variable

    init_gpio();
    init_i2c();
    adc_init();
    adc_gpio_init(ADC_PIN);
    adc_select_input(ADC_NUM);

    gpio_put(GREEN_LED_PIN, 1); // Start in idle state with green LED on

    float sum_db = 0;
    int count = 0;

    while (1) {
        if (gpio_get(PUSH_BUTTON_PIN) == 0 && is_debounced(PUSH_BUTTON_PIN)) {
            switch (state) {
                case IDLE:
                    state = OPERATION;
                    start_time = time_us_64();
                    gpio_put(GREEN_LED_PIN, 0);
                    gpio_put(YELLOW_LED_PIN, 1);
                    sum_db = 0;
                    count = 0;
                    break;
                
                case OPERATION:
                    state = CANCELLED;
                    gpio_put(YELLOW_LED_PIN, 0);
                    gpio_put(RED_LED_PIN, 1);
                    printf("CANCELLED\n");
                    break;
                
                case SUCCESSFUL:
                    state = IDLE;
                    gpio_put(GREEN_LED_PIN, 1);
                    break;
                
                case CANCELLED:
                    gpio_put(RED_LED_PIN, 0);
                    state = IDLE;
                    gpio_put(GREEN_LED_PIN, 1);
                    break;
            }
        }

        if (reset_button_pressed) {
            reset_button_pressed = false;
            erase_eeprom_memory();
            printf("MEMORY HAS BEEN CLEANED\n");
        }

        if (gpio_get(DUMP_BUTTON_PIN) == 0 && is_debounced(DUMP_BUTTON_PIN)) {
            printf("\n\nLAST DATA\n");
            dump_data_from_eeprom();
            printf("END OF DATA");
        }

        switch (state) {
            case OPERATION:
                if ((time_us_64() - start_time) < 10000000) { // 10 seconds
                    sum_db += measure_audio();
                    count++;
                    sleep_ms(100); // Sleep between measurements to reduce CPU usage
                } else {
                    state = SUCCESSFUL;
                    gpio_put(YELLOW_LED_PIN, 0);
                }
                break;
            
            case CANCELLED:
                if ((time_us_64() - start_time) >= 3000000) { // 3 seconds
                    state = IDLE;
                    gpio_put(RED_LED_PIN, 0);
                    gpio_put(GREEN_LED_PIN, 1);
                }
                break;

            case SUCCESSFUL:
                for (int i = 0; i < 3; i++) {
                    gpio_put(BLUE_LED_PIN, 1);
                    sleep_ms(500);
                    gpio_put(BLUE_LED_PIN, 0);
                    sleep_ms(500);
                }

                float average_db = sum_db / count;
                printf("Average Sound Level: %.2f dB\n", average_db);
                save_average_db(average_db);

                state = IDLE;
                gpio_put(GREEN_LED_PIN, 1);
                break;
        }
        sleep_ms(10);
    }
}
