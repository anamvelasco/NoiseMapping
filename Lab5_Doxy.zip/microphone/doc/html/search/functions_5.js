var searchData=
[
  ['measure_5faudio_0',['measure_audio',['../microphone_8h.html#a82d57d11c62c937e0f017913d277c34d',1,'microphone.h']]]
];
