var searchData=
[
  ['samples_0',['SAMPLES',['../microphone_8h.html#ad0c329adebc27917fc0a4f51079acf6a',1,'microphone.h']]],
  ['save_5faverage_5fdb_1',['save_average_db',['../microphone_8h.html#ab8d67171090b6f6720bc6a64fe251f16',1,'microphone.h']]],
  ['state_2',['state',['../microphone_8h.html#a7722b3e958993a1a070becc413c17c2a',1,'microphone.h']]],
  ['successful_3',['SUCCESSFUL',['../microphone_8h.html#a1be7a56cdddcdb7dedf16d4dee381e93',1,'microphone.h']]]
];
