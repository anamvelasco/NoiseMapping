var searchData=
[
  ['samples_0',['SAMPLES',['../microphone_8h.html#ad0c329adebc27917fc0a4f51079acf6a',1,'microphone.h']]],
  ['successful_1',['SUCCESSFUL',['../microphone_8h.html#a1be7a56cdddcdb7dedf16d4dee381e93',1,'microphone.h']]]
];
