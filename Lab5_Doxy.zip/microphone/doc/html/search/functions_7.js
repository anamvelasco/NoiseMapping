var searchData=
[
  ['save_5faverage_5fdb_0',['save_average_db',['../microphone_8h.html#ab8d67171090b6f6720bc6a64fe251f16',1,'microphone.h']]]
];
