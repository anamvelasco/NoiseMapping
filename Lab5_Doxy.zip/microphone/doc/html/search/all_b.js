var searchData=
[
  ['operation_0',['OPERATION',['../microphone_8h.html#a32c08469940a939beac7000bbbfbab94',1,'microphone.h']]]
];
