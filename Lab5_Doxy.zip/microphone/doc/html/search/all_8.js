var searchData=
[
  ['last_5fpress_5ftime_0',['last_press_time',['../microphone_8h.html#a0d8ccf9435b4d329fc12f94c07ed04af',1,'microphone.h']]],
  ['libraries_1',['Libraries',['../index.html#libraries',1,'']]]
];
