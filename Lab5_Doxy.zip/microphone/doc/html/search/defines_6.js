var searchData=
[
  ['i2c_5fport_0',['I2C_PORT',['../microphone_8h.html#ad9ecf80e1eac083d16ec47f9d3aeb39f',1,'microphone.h']]],
  ['i2c_5fscl_5fpin_1',['I2C_SCL_PIN',['../microphone_8h.html#a0e4e08bab2fb484136d18b067bef372c',1,'microphone.h']]],
  ['i2c_5fsda_5fpin_2',['I2C_SDA_PIN',['../microphone_8h.html#a2cade698267beb86ccaa38c14d35ab0f',1,'microphone.h']]],
  ['idle_3',['IDLE',['../microphone_8h.html#a9c21a7caee326d7803b94ae1952b27ca',1,'microphone.h']]]
];
