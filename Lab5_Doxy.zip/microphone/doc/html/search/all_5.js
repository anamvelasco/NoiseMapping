var searchData=
[
  ['find_5fnext_5fwrite_5faddress_0',['find_next_write_address',['../microphone_8h.html#ad2f0ff315fcdb7c4185b1b4300b6c627',1,'microphone.h']]]
];
