var searchData=
[
  ['init_5fgpio_0',['init_gpio',['../microphone_8h.html#a2ffbeae6c737f0ed50e4614eec56ef76',1,'microphone.h']]],
  ['init_5fi2c_1',['init_i2c',['../microphone_8h.html#a4a79eff98f9a3527ef7af069c1d38697',1,'microphone.h']]],
  ['is_5fdebounced_2',['is_debounced',['../microphone_8h.html#a15fdfd84267015bccf648fdd6e09dd28',1,'microphone.h']]]
];
