/**
 * @file microphone.h
 *
 * @brief Header file for the Noise Meter program (microphone.c)
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/i2c.h"
#include "hardware/rtc.h"
#include <math.h>
#include "pico/util/datetime.h"
#include <string.h>
#include <time.h>

// GPIO pins
#define ADC_NUM 0  ///< Defines the ADC number used for analog-to-digital conversion.
#define ADC_PIN (26 + ADC_NUM)  ///< Defines the GPIO pin number connected to the ADC.
#define ADC_VREF 3.3  ///< Defines the reference voltage (Vref) for the ADC.
#define ADC_RANGE (1 << 12)  ///< Defines the range of the ADC (2^12 for 12-bit resolution).
#define ADC_CONVERT (ADC_VREF / (ADC_RANGE - 1))  ///< Defines the conversion factor for converting ADC raw values to voltage.
#define SAMPLES 100  ///< Defines the number of samples to be averaged for sound level measurement.

#define PUSH_BUTTON_PIN 15  ///< Defines the GPIO pin number for the push button.
#define DUMP_BUTTON_PIN 16  ///< Defines the GPIO pin number for the dump button.
#define GREEN_LED_PIN 13  ///< Defines the GPIO pin number for the green LED.
#define YELLOW_LED_PIN 12  ///< Defines the GPIO pin number for the yellow LED.
#define BLUE_LED_PIN 11  ///< Defines the GPIO pin number for the blue LED.
#define RED_LED_PIN 10  ///< Defines the GPIO pin number for the red LED.
#define RESET_BUTTON_PIN 20  ///< Defines the GPIO pin number for the reset button.

#define I2C_SDA_PIN 4  ///< Defines the I2C serial data (SDA) pin number.
#define I2C_SCL_PIN 5  ///< Defines the I2C serial clock (SCL) pin number.
#define I2C_PORT i2c0  ///< Defines the I2C port to be used for communication.
#define EEPROM_ADDRESS 0x50  ///< Defines the EEPROM memory address.

#define IDLE 0  ///< Defines the idle state of the program.
#define OPERATION 1  ///< Defines the operation state of the program.
#define SUCCESSFUL 2  ///< Defines the successful state of the program.
#define CANCELLED 3  ///< Defines the cancelled state of the program.

volatile int state = IDLE;  ///< Stores the current state of the program.
volatile uint64_t last_press_time[PUSH_BUTTON_PIN + 1];  ///< Stores the last time each button was pressed.
volatile bool reset_button_pressed = false;  ///< Indicates whether the reset button has been pressed.




/**
 * @brief Interruption callback to handle reset_push button.
 */
void gpio_callback(uint gpio, uint32_t events) {
    if (gpio == RESET_BUTTON_PIN && (events & GPIO_IRQ_EDGE_FALL)) {
        reset_button_pressed = true;
    }
}


/**
 * @brief Initializes GPIO pins for LEDs and buttons.
 */
void init_gpio() {
    gpio_init(GREEN_LED_PIN);
    gpio_set_dir(GREEN_LED_PIN, GPIO_OUT);
    
    gpio_init(YELLOW_LED_PIN);
    gpio_set_dir(YELLOW_LED_PIN, GPIO_OUT);
    
    gpio_init(BLUE_LED_PIN);
    gpio_set_dir(BLUE_LED_PIN, GPIO_OUT);
    
    gpio_init(RED_LED_PIN);
    gpio_set_dir(RED_LED_PIN, GPIO_OUT);
    
    gpio_init(PUSH_BUTTON_PIN);
    gpio_set_dir(PUSH_BUTTON_PIN, GPIO_IN);
    gpio_pull_up(PUSH_BUTTON_PIN);

    gpio_init(DUMP_BUTTON_PIN);
    gpio_set_dir(DUMP_BUTTON_PIN, GPIO_IN);
    gpio_pull_up(DUMP_BUTTON_PIN);

    gpio_init(RESET_BUTTON_PIN);
    gpio_set_dir(RESET_BUTTON_PIN, GPIO_IN);
    gpio_pull_up(RESET_BUTTON_PIN);
    gpio_set_irq_enabled_with_callback(RESET_BUTTON_PIN, GPIO_IRQ_EDGE_FALL, true, &gpio_callback);
}

/**
 * @brief Initializes I2C communication.
 */
void init_i2c() {
    i2c_init(I2C_PORT, 100 * 1000);
    gpio_set_function(I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA_PIN);
    gpio_pull_up(I2C_SCL_PIN);
}


/**
 * @brief Writes data to the EEPROM at the specified address.
 *
 * @param address The memory address to write data to.
 * @param data Pointer to the data buffer to be written.
 * @param length The length of the data to be written.
 */
void write_to_eeprom(uint16_t address, uint8_t* data, size_t length) {
    uint8_t buffer[length + 2];
    buffer[0] = address >> 8;
    buffer[1] = address & 0xFF;
    memcpy(&buffer[2], data, length);
    i2c_write_blocking(I2C_PORT, EEPROM_ADDRESS, buffer, length + 2, false);
    sleep_ms(5);  // EEPROM write delay
}


/**
 * @brief Reads data from the EEPROM at the specified address.
 *
 * @param address The memory address to read data from.
 * @param data Pointer to the buffer to store the read data.
 * @param length The length of the data to be read.
 */
void read_from_eeprom(uint16_t address, uint8_t* data, size_t length) {
    uint8_t address_bytes[] = {address >> 8, address & 0xFF};
    i2c_write_blocking(I2C_PORT, EEPROM_ADDRESS, address_bytes, 2, true);
    i2c_read_blocking(I2C_PORT, EEPROM_ADDRESS, data, length, false);
}


/**
 * @brief Finds the next available memory address for writing to the EEPROM.
 *
 * @return The next available memory address.
 */
uint16_t find_next_write_address() {
    uint16_t address = 0;
    uint8_t buffer[5];  // Buffer to read 5 bytes (dB value + timestamp)
    while (address < 0x7FFF) {  // Assuming 32KB EEPROM
        read_from_eeprom(address, buffer, sizeof(buffer));
        if (buffer[0] == 0xFF) {
            break;  // Found an empty slot
        }
       
        address += sizeof(buffer);
    }
    return address;
}


/**
 * @brief Saves the average sound level to the EEPROM with a timestamp.
 *
 * @param average_db The average sound level in decibels (dB) to be saved.
 */
void save_average_db(float average_db) {
    uint16_t address = find_next_write_address();
    if (address < 0x7FFF) {
        uint8_t data[5]; // Keep the data size to store dB value and timestamp
        int16_t db_value = (int16_t)(average_db * 100);  // Store dB value with 2 decimal places
        data[0] = db_value >> 8;
        data[1] = db_value & 0xFF;

        // Get current system time
        time_t current_time = time(NULL);
        struct tm *local_time = localtime(&current_time);

        // Store the timestamp in EEPROM
        data[2] = local_time->tm_hour;
        data[3] = local_time->tm_min;
        data[4] = local_time->tm_sec;

        write_to_eeprom(address, data, sizeof(data));
    }
}


/**
 * @brief Erases the entire EEPROM memory.
 */
void erase_eeprom_memory() {
    for (uint16_t address = 0; address < 0x7FFF; address += 64) { // Erase 64 bytes at a time
        uint8_t erase_data[64];
        memset(erase_data, 0xFF, sizeof(erase_data)); // Fill with 0xFF
        write_to_eeprom(address, erase_data, sizeof(erase_data));
    }
}

/**
 * @brief Dumps data from the EEPROM and prints it to the console.
 */
void dump_data_from_eeprom() {
    uint16_t address = 0;
    uint8_t buffer[5];
    int max_iterations = 1000; // Set a maximum number of iterations
    int iterations = 0;
    while (address < 0x7FFF && iterations < max_iterations) {
        read_from_eeprom(address, buffer, sizeof(buffer));
        if (buffer[0] == 0xFF) {
            break;  // No more data
        }
        int16_t db_value = (buffer[0] << 8) | buffer[1];
        float db = db_value / 100.0;

        // Extract timestamp
        struct tm tm_info;
        tm_info.tm_hour = buffer[2];
        tm_info.tm_min = buffer[3];
        tm_info.tm_sec = buffer[4];
        tm_info.tm_mday = 1; // Dummy value for day
        tm_info.tm_mon = 0;  // Dummy value for month (January)
        tm_info.tm_year = 100; // Dummy value for year (2000)

        // Convert to time_t
        time_t timestamp = mktime(&tm_info);

        // Format the time as required
        char time_str[30];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", &tm_info);

        printf("dB: %.2f, Time: %s\n", db, time_str);
        address += sizeof(buffer);
        iterations++; // Increment the iteration counter
    }
    if (iterations >= max_iterations) {
        printf("Maximum number of iterations reached. Exiting dump operation.\n");
    }
}



/**
 * @brief Measures the audio level using an ADC connected to a microphone.
 *
 * @return The measured sound level in decibels (dB).
 */
float measure_audio() {
    uint adc_raw;
    float adc_voltage;
    float sum = 0;
    for (int i = 0; i < SAMPLES; i++) {
        adc_raw = adc_read();
        adc_voltage = adc_raw * ADC_CONVERT;
        sum += adc_voltage * adc_voltage;
        sleep_ms(1);
    }
    float rms = sqrt(sum / SAMPLES);
    float db = 20 * log10(rms / ADC_VREF);
    return db;
}



/**
 * @brief Checks if a GPIO input is debounced (prevents rapid button presses).
 *
 * @param gpio The GPIO pin number to check for debounce.
 * @return True if the button press is debounced, false otherwise.
 */
bool is_debounced(uint gpio) {
    uint64_t current_time = time_us_64();
    if (current_time - last_press_time[gpio] >= 200000) { // 200ms debounce time
        last_press_time[gpio] = current_time;
        return true;
    }
    return false;
}