#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/i2c.h"
#include "hardware/rtc.h"
#include <math.h>
#include "pico/util/datetime.h"
#include <string.h>
#include <time.h>

// GPIO pins
#define ADC_NUM 0
#define ADC_PIN (26 + ADC_NUM)
#define ADC_VREF 3.3
#define ADC_RANGE (1 << 12)
#define ADC_CONVERT (ADC_VREF / (ADC_RANGE - 1))
#define SAMPLES 100

#define PUSH_BUTTON_PIN 15
#define DUMP_BUTTON_PIN 16
#define GREEN_LED_PIN 13
#define YELLOW_LED_PIN 12
#define BLUE_LED_PIN 11
#define RED_LED_PIN 10

// I2C pins
#define I2C_SDA_PIN 4
#define I2C_SCL_PIN 5
#define I2C_PORT i2c0
#define EEPROM_ADDRESS 0x50

#define IDLE 0
#define OPERATION 1
#define SUCCESSFUL 2
#define CANCELLED 3

volatile int state = IDLE;
volatile bool button_pressed = false;
volatile bool dump_button_pressed = false;
volatile uint64_t start_time;

void gpio_callback(uint gpio, uint32_t events) {
    if (gpio == PUSH_BUTTON_PIN && (events & GPIO_IRQ_EDGE_FALL)) {
        button_pressed = true;
    }
    if (gpio == DUMP_BUTTON_PIN && (events & GPIO_IRQ_EDGE_FALL)) {
        dump_button_pressed = true;
    }
}

void init_gpio() {
    gpio_init(GREEN_LED_PIN);
    gpio_set_dir(GREEN_LED_PIN, GPIO_OUT);
    
    gpio_init(YELLOW_LED_PIN);
    gpio_set_dir(YELLOW_LED_PIN, GPIO_OUT);
    
    gpio_init(BLUE_LED_PIN);
    gpio_set_dir(BLUE_LED_PIN, GPIO_OUT);
    
    gpio_init(RED_LED_PIN);
    gpio_set_dir(RED_LED_PIN, GPIO_OUT);
    
    gpio_init(PUSH_BUTTON_PIN);
    gpio_set_dir(PUSH_BUTTON_PIN, GPIO_IN);
    gpio_pull_up(PUSH_BUTTON_PIN);
    gpio_set_irq_enabled_with_callback(PUSH_BUTTON_PIN, GPIO_IRQ_EDGE_FALL, true, &gpio_callback);

    gpio_init(DUMP_BUTTON_PIN);
    gpio_set_dir(DUMP_BUTTON_PIN, GPIO_IN);
    gpio_pull_up(DUMP_BUTTON_PIN);
    gpio_set_irq_enabled_with_callback(DUMP_BUTTON_PIN, GPIO_IRQ_EDGE_FALL, true, &gpio_callback);
}

void init_i2c() {
    i2c_init(I2C_PORT, 100 * 1000);
    gpio_set_function(I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA_PIN);
    gpio_pull_up(I2C_SCL_PIN);
}

void write_to_eeprom(uint16_t address, uint8_t* data, size_t length) {
    uint8_t buffer[length + 2];
    buffer[0] = address >> 8;
    buffer[1] = address & 0xFF;
    memcpy(&buffer[2], data, length);
    i2c_write_blocking(I2C_PORT, EEPROM_ADDRESS, buffer, length + 2, false);
    sleep_ms(5);  // EEPROM write delay
}

void read_from_eeprom(uint16_t address, uint8_t* data, size_t length) {
    uint8_t address_bytes[] = {address >> 8, address & 0xFF};
    i2c_write_blocking(I2C_PORT, EEPROM_ADDRESS, address_bytes, 2, true);
    i2c_read_blocking(I2C_PORT, EEPROM_ADDRESS, data, length, false);
}

uint16_t find_next_write_address() {
    uint16_t address = 0;
    uint8_t buffer[5];  // Buffer to read 5 bytes (dB value + timestamp)
    while (address < 0x7FFF) {  // Assuming 32KB EEPROM
        read_from_eeprom(address, buffer, sizeof(buffer));
        if (buffer[0] == 0xFF) {
            break;  // Found an empty slot
        }
        address += sizeof(buffer);
    }
    return address;
}

void save_average_db(float average_db) {
    uint16_t address = find_next_write_address();
    if (address < 0x7FFF) {
        uint8_t data[5]; // Keep the data size to store dB value and timestamp
        int16_t db_value = (int16_t)(average_db * 100);  // Store dB value with 2 decimal places
        data[0] = db_value >> 8;
        data[1] = db_value & 0xFF;

        // Get current system time
        time_t current_time = time(NULL);
        struct tm *local_time = localtime(&current_time);

        // Store the timestamp in EEPROM
        data[2] = local_time->tm_hour;
        data[3] = local_time->tm_min;
        data[4] = local_time->tm_sec;

        write_to_eeprom(address, data, sizeof(data));
    }
}





void dump_data_from_eeprom() {
    uint16_t address = 0;
    uint8_t buffer[5];
    int max_iterations = 1000; // Set a maximum number of iterations
    int iterations = 0;
    while (address < 0x7FFF && iterations < max_iterations) {
        read_from_eeprom(address, buffer, sizeof(buffer));
        if (buffer[0] == 0xFF) {
            break;  // No more data
        }
        int16_t db_value = (buffer[0] << 8) | buffer[1];
        float db = db_value / 100.0;

        // Extract timestamp
        struct tm tm_info;
        tm_info.tm_hour = buffer[2];
        tm_info.tm_min = buffer[3];
        tm_info.tm_sec = buffer[4];
        tm_info.tm_mday = 1; // Dummy value for day
        tm_info.tm_mon = 0;  // Dummy value for month (January)
        tm_info.tm_year = 100; // Dummy value for year (2000)

        // Convert to time_t
        time_t timestamp = mktime(&tm_info);

        // Format the time as required
        char time_str[30];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", &tm_info);

        printf("dB: %.2f, Time: %s\n", db, time_str);
        address += sizeof(buffer);
        iterations++; // Increment the iteration counter
    }
    if (iterations >= max_iterations) {
        printf("Maximum number of iterations reached. Exiting dump operation.\n");
    }
}

float measure_audio() {
    uint adc_raw;
    float adc_voltage;
    float sum = 0;
    for (int i = 0; i < SAMPLES; i++) {
        adc_raw = adc_read();
        adc_voltage = adc_raw * ADC_CONVERT;
        sum += adc_voltage * adc_voltage;
        sleep_ms(1);
    }
    float rms = sqrt(sum / SAMPLES);
    float db = 20 * log10(rms / ADC_VREF);
    return db;
}

int main() {
    stdio_init_all();
    printf("System initializing...\n");

    init_gpio();
    init_i2c();
    adc_init();
    adc_gpio_init(ADC_PIN);
    adc_select_input(ADC_NUM);

    gpio_put(GREEN_LED_PIN, 1); // Start in idle state with green LED on

    float sum_db = 0;
    int count = 0;

    while (1) {
        switch (state) {
            case IDLE:
                if (button_pressed) {
                    button_pressed = false;
                    state = OPERATION;
                    start_time = time_us_64();
                    gpio_put(GREEN_LED_PIN, 0);
                    gpio_put(YELLOW_LED_PIN, 1);
                    sum_db = 0;
                    count = 0;
                }
                if (dump_button_pressed) {
                    dump_button_pressed = false;
                    dump_data_from_eeprom();
                }
                break;
            
            case OPERATION:
                if (button_pressed) {
                    button_pressed = false;
                    state = CANCELLED;
                    gpio_put(YELLOW_LED_PIN, 0);
                    gpio_put(RED_LED_PIN, 1);
                    printf("CANCELLED\n");
                } else if ((time_us_64() - start_time) < 10000000) { // 10 seconds
                    sum_db += measure_audio();
                    count++;
                    sleep_ms(100); // Sleep between measurements to reduce CPU usage
                } else {
                    state = SUCCESSFUL;
                    gpio_put(YELLOW_LED_PIN, 0);
                }
                break;
            
            case SUCCESSFUL:
                for (int i = 0; i < 3; i++) {
                    gpio_put(BLUE_LED_PIN, 1);
                    sleep_ms(500);
                    gpio_put(BLUE_LED_PIN, 0);
                    sleep_ms(500);
                }

                float average_db = sum_db / count;
                printf("Average Sound Level: %.2f dB\n", average_db);
                save_average_db(average_db);

                state = IDLE;
                gpio_put(GREEN_LED_PIN, 1);
                break;
            
            case CANCELLED:
                sleep_ms(3000); // Red LED on for 3 seconds
                gpio_put(RED_LED_PIN, 0);
                state = IDLE;
                gpio_put(GREEN_LED_PIN, 1);
                break;
        }
        sleep_ms(10);
    }
}

